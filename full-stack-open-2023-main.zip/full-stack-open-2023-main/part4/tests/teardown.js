module.exports = () => {
    process.exit(0)
  }